--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 16.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE pttk;
--
-- Name: pttk; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE pttk WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'vi-VN';


ALTER DATABASE pttk OWNER TO postgres;

\connect pttk

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bỘ_phẬn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."bỘ_phẬn" (
    "id_bộ_phận" character varying(50) NOT NULL,
    "tên_bộ_phận" character varying(100) NOT NULL
);


ALTER TABLE public."bỘ_phẬn" OWNER TO postgres;

--
-- Name: chi_tiẾt_hoÁ_ĐƠn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."chi_tiẾt_hoÁ_ĐƠn" (
    "id_chi_tiết" character varying(50) NOT NULL,
    "id_hoá_đơn" character varying(50),
    "id_dịch_vụ" character varying(50),
    "số_lượng" integer NOT NULL,
    "giá_tại_thời_điểm" integer NOT NULL,
    "thành_tiền" integer NOT NULL
);


ALTER TABLE public."chi_tiẾt_hoÁ_ĐƠn" OWNER TO postgres;

--
-- Name: dỊch_vỤ; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."dỊch_vỤ" (
    "id_dịch_vụ" character varying(50) NOT NULL,
    "tên_dịch_vụ" character varying(100) NOT NULL,
    "giá" integer NOT NULL,
    "trạng_thái" character varying(50) NOT NULL
);


ALTER TABLE public."dỊch_vỤ" OWNER TO postgres;

--
-- Name: hoÁ_ĐƠn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."hoÁ_ĐƠn" (
    "id_hoá_đơn" character varying(50) NOT NULL,
    "id_hộ" character varying(50),
    "số_tiền" integer NOT NULL,
    "tháng_năm" date NOT NULL,
    "ngày_tạo" date NOT NULL,
    "trạng_thái" character varying(50),
    CONSTRAINT "hoÁ_ĐƠn_trạng_thái_check" CHECK ((("trạng_thái")::text = ANY ((ARRAY['chưa thanh toán'::character varying, 'đã thanh toán'::character varying])::text[])))
);


ALTER TABLE public."hoÁ_ĐƠn" OWNER TO postgres;

--
-- Name: hỘ_cƯ_dÂn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."hỘ_cƯ_dÂn" (
    "id_hộ" character varying(50) NOT NULL,
    "id_tài_khoản" character varying(50),
    "số_phòng" integer NOT NULL,
    "tên_đại_diện" character varying(100) NOT NULL,
    "sđt_đại_diện" character varying(15) NOT NULL,
    "số_thành_viên" integer NOT NULL
);


ALTER TABLE public."hỘ_cƯ_dÂn" OWNER TO postgres;

--
-- Name: nhiỆm_vỤ; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."nhiỆm_vỤ" (
    "id_nhiệm_vụ" character varying(50) NOT NULL,
    "tên_nhiệm_vụ" character varying(100) NOT NULL,
    "mô_tả" text,
    "id_người_giao" character varying(50),
    "id_người_nhận" character varying(50),
    "hạn_hoàn_thành" date NOT NULL
);


ALTER TABLE public."nhiỆm_vỤ" OWNER TO postgres;

--
-- Name: nhÂn_viÊn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."nhÂn_viÊn" (
    "id_nhân_viên" character varying(50) NOT NULL,
    "tên_nhân_viên" character varying(100) NOT NULL,
    "id_bộ_phận" character varying(50),
    "id_tài_khoản" character varying(50),
    "ngày_bắt_đầu" date NOT NULL,
    "chức_vụ" character varying(50),
    "trạng_thái" character varying(50) NOT NULL,
    "số_điện_thoại" character varying(15) NOT NULL,
    "địa_chỉ" character varying(200) NOT NULL,
    CONSTRAINT "nhÂn_viÊn_chức_vụ_check" CHECK ((("chức_vụ")::text = ANY ((ARRAY['nhân viên'::character varying, 'trưởng bộ phận'::character varying])::text[])))
);


ALTER TABLE public."nhÂn_viÊn" OWNER TO postgres;

--
-- Name: sỰ_cỐ; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."sỰ_cỐ" (
    "id_sự_cố" character varying(50) NOT NULL,
    "tên_sự_cố" character varying(100) NOT NULL,
    "loại_sự_cố" character varying(50),
    "thời_gian_báo_cáo" date NOT NULL,
    "id_người_báo_cáo" character varying(50),
    "id_người_trách_nhiệm" character varying(50),
    "mô_tả" text,
    "trạng_thái" character varying(50) NOT NULL,
    CONSTRAINT "sỰ_cỐ_loại_sự_cố_check" CHECK ((("loại_sự_cố")::text = ANY ((ARRAY['Bộ phận Lễ Tân'::character varying, 'Bộ phận Kế toán'::character varying, 'Bộ phận Vệ sinh'::character varying, 'Bộ phận Kỹ thuật'::character varying, 'Bộ phận Bảo vệ'::character varying])::text[])))
);


ALTER TABLE public."sỰ_cỐ" OWNER TO postgres;

--
-- Name: thanh_toÁn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."thanh_toÁn" (
    "id_thanh_toán" character varying(50) NOT NULL,
    "id_hoá_đơn" character varying(50),
    "số_tiền" integer NOT NULL,
    "ngày_thanh_toán" date NOT NULL,
    "phương_thức" character varying(50),
    "id_người_xác_nhận" character varying(50),
    CONSTRAINT "thanh_toÁn_phương_thức_check" CHECK ((("phương_thức")::text = ANY ((ARRAY['tiền mặt'::character varying, 'chuyển khoản'::character varying])::text[])))
);


ALTER TABLE public."thanh_toÁn" OWNER TO postgres;

--
-- Name: thÔng_bÁo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."thÔng_bÁo" (
    "id_thông_báo" character varying(50) NOT NULL,
    "id_thanh_toán" character varying(50),
    "id_hộ" character varying(50),
    "nội_dung" text NOT NULL
);


ALTER TABLE public."thÔng_bÁo" OWNER TO postgres;

--
-- Name: tÀi_khoẢn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."tÀi_khoẢn" (
    "id_tài_khoản" character varying(50) NOT NULL,
    "tên_người_dùng" character varying(100) NOT NULL,
    "mật_khẩu" character varying(100) NOT NULL
);


ALTER TABLE public."tÀi_khoẢn" OWNER TO postgres;

--
-- Name: ĐĂng_kÝ_dỊch_vỤ; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ĐĂng_kÝ_dỊch_vỤ" (
    "id_đăng_ký" character varying(50) NOT NULL,
    "id_hộ" character varying(50),
    "id_dịch_vụ" character varying(50),
    "ngày_bắt_đầu" date NOT NULL,
    "trạng_thái" character varying(50),
    CONSTRAINT "ĐĂng_kÝ_dỊch_vỤ_trạng_thái_check" CHECK ((("trạng_thái")::text = ANY ((ARRAY['đang dùng'::character varying, 'đã hủy'::character varying])::text[])))
);


ALTER TABLE public."ĐĂng_kÝ_dỊch_vỤ" OWNER TO postgres;

--
-- Data for Name: bỘ_phẬn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."bỘ_phẬn" ("id_bộ_phận", "tên_bộ_phận") FROM stdin;
\.
COPY public."bỘ_phẬn" ("id_bộ_phận", "tên_bộ_phận") FROM '$$PATH$$/4871.dat';

--
-- Data for Name: chi_tiẾt_hoÁ_ĐƠn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."chi_tiẾt_hoÁ_ĐƠn" ("id_chi_tiết", "id_hoá_đơn", "id_dịch_vụ", "số_lượng", "giá_tại_thời_điểm", "thành_tiền") FROM stdin;
\.
COPY public."chi_tiẾt_hoÁ_ĐƠn" ("id_chi_tiết", "id_hoá_đơn", "id_dịch_vụ", "số_lượng", "giá_tại_thời_điểm", "thành_tiền") FROM '$$PATH$$/4876.dat';

--
-- Data for Name: dỊch_vỤ; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."dỊch_vỤ" ("id_dịch_vụ", "tên_dịch_vụ", "giá", "trạng_thái") FROM stdin;
\.
COPY public."dỊch_vỤ" ("id_dịch_vụ", "tên_dịch_vụ", "giá", "trạng_thái") FROM '$$PATH$$/4873.dat';

--
-- Data for Name: hoÁ_ĐƠn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."hoÁ_ĐƠn" ("id_hoá_đơn", "id_hộ", "số_tiền", "tháng_năm", "ngày_tạo", "trạng_thái") FROM stdin;
\.
COPY public."hoÁ_ĐƠn" ("id_hoá_đơn", "id_hộ", "số_tiền", "tháng_năm", "ngày_tạo", "trạng_thái") FROM '$$PATH$$/4875.dat';

--
-- Data for Name: hỘ_cƯ_dÂn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."hỘ_cƯ_dÂn" ("id_hộ", "id_tài_khoản", "số_phòng", "tên_đại_diện", "sđt_đại_diện", "số_thành_viên") FROM stdin;
\.
COPY public."hỘ_cƯ_dÂn" ("id_hộ", "id_tài_khoản", "số_phòng", "tên_đại_diện", "sđt_đại_diện", "số_thành_viên") FROM '$$PATH$$/4870.dat';

--
-- Data for Name: nhiỆm_vỤ; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."nhiỆm_vỤ" ("id_nhiệm_vụ", "tên_nhiệm_vụ", "mô_tả", "id_người_giao", "id_người_nhận", "hạn_hoàn_thành") FROM stdin;
\.
COPY public."nhiỆm_vỤ" ("id_nhiệm_vụ", "tên_nhiệm_vụ", "mô_tả", "id_người_giao", "id_người_nhận", "hạn_hoàn_thành") FROM '$$PATH$$/4878.dat';

--
-- Data for Name: nhÂn_viÊn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."nhÂn_viÊn" ("id_nhân_viên", "tên_nhân_viên", "id_bộ_phận", "id_tài_khoản", "ngày_bắt_đầu", "chức_vụ", "trạng_thái", "số_điện_thoại", "địa_chỉ") FROM stdin;
\.
COPY public."nhÂn_viÊn" ("id_nhân_viên", "tên_nhân_viên", "id_bộ_phận", "id_tài_khoản", "ngày_bắt_đầu", "chức_vụ", "trạng_thái", "số_điện_thoại", "địa_chỉ") FROM '$$PATH$$/4872.dat';

--
-- Data for Name: sỰ_cỐ; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."sỰ_cỐ" ("id_sự_cố", "tên_sự_cố", "loại_sự_cố", "thời_gian_báo_cáo", "id_người_báo_cáo", "id_người_trách_nhiệm", "mô_tả", "trạng_thái") FROM stdin;
\.
COPY public."sỰ_cỐ" ("id_sự_cố", "tên_sự_cố", "loại_sự_cố", "thời_gian_báo_cáo", "id_người_báo_cáo", "id_người_trách_nhiệm", "mô_tả", "trạng_thái") FROM '$$PATH$$/4879.dat';

--
-- Data for Name: thanh_toÁn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."thanh_toÁn" ("id_thanh_toán", "id_hoá_đơn", "số_tiền", "ngày_thanh_toán", "phương_thức", "id_người_xác_nhận") FROM stdin;
\.
COPY public."thanh_toÁn" ("id_thanh_toán", "id_hoá_đơn", "số_tiền", "ngày_thanh_toán", "phương_thức", "id_người_xác_nhận") FROM '$$PATH$$/4877.dat';

--
-- Data for Name: thÔng_bÁo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."thÔng_bÁo" ("id_thông_báo", "id_thanh_toán", "id_hộ", "nội_dung") FROM stdin;
\.
COPY public."thÔng_bÁo" ("id_thông_báo", "id_thanh_toán", "id_hộ", "nội_dung") FROM '$$PATH$$/4880.dat';

--
-- Data for Name: tÀi_khoẢn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."tÀi_khoẢn" ("id_tài_khoản", "tên_người_dùng", "mật_khẩu") FROM stdin;
\.
COPY public."tÀi_khoẢn" ("id_tài_khoản", "tên_người_dùng", "mật_khẩu") FROM '$$PATH$$/4869.dat';

--
-- Data for Name: ĐĂng_kÝ_dỊch_vỤ; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ĐĂng_kÝ_dỊch_vỤ" ("id_đăng_ký", "id_hộ", "id_dịch_vụ", "ngày_bắt_đầu", "trạng_thái") FROM stdin;
\.
COPY public."ĐĂng_kÝ_dỊch_vỤ" ("id_đăng_ký", "id_hộ", "id_dịch_vụ", "ngày_bắt_đầu", "trạng_thái") FROM '$$PATH$$/4874.dat';

--
-- Name: bỘ_phẬn bỘ_phẬn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."bỘ_phẬn"
    ADD CONSTRAINT "bỘ_phẬn_pkey" PRIMARY KEY ("id_bộ_phận");


--
-- Name: chi_tiẾt_hoÁ_ĐƠn chi_tiẾt_hoÁ_ĐƠn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."chi_tiẾt_hoÁ_ĐƠn"
    ADD CONSTRAINT "chi_tiẾt_hoÁ_ĐƠn_pkey" PRIMARY KEY ("id_chi_tiết");


--
-- Name: dỊch_vỤ dỊch_vỤ_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."dỊch_vỤ"
    ADD CONSTRAINT "dỊch_vỤ_pkey" PRIMARY KEY ("id_dịch_vụ");


--
-- Name: hoÁ_ĐƠn hoÁ_ĐƠn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."hoÁ_ĐƠn"
    ADD CONSTRAINT "hoÁ_ĐƠn_pkey" PRIMARY KEY ("id_hoá_đơn");


--
-- Name: hỘ_cƯ_dÂn hỘ_cƯ_dÂn_id_tài_khoản_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."hỘ_cƯ_dÂn"
    ADD CONSTRAINT "hỘ_cƯ_dÂn_id_tài_khoản_key" UNIQUE ("id_tài_khoản");


--
-- Name: hỘ_cƯ_dÂn hỘ_cƯ_dÂn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."hỘ_cƯ_dÂn"
    ADD CONSTRAINT "hỘ_cƯ_dÂn_pkey" PRIMARY KEY ("id_hộ");


--
-- Name: nhiỆm_vỤ nhiỆm_vỤ_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."nhiỆm_vỤ"
    ADD CONSTRAINT "nhiỆm_vỤ_pkey" PRIMARY KEY ("id_nhiệm_vụ");


--
-- Name: nhÂn_viÊn nhÂn_viÊn_id_tài_khoản_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."nhÂn_viÊn"
    ADD CONSTRAINT "nhÂn_viÊn_id_tài_khoản_key" UNIQUE ("id_tài_khoản");


--
-- Name: nhÂn_viÊn nhÂn_viÊn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."nhÂn_viÊn"
    ADD CONSTRAINT "nhÂn_viÊn_pkey" PRIMARY KEY ("id_nhân_viên");


--
-- Name: sỰ_cỐ sỰ_cỐ_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."sỰ_cỐ"
    ADD CONSTRAINT "sỰ_cỐ_pkey" PRIMARY KEY ("id_sự_cố");


--
-- Name: thanh_toÁn thanh_toÁn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."thanh_toÁn"
    ADD CONSTRAINT "thanh_toÁn_pkey" PRIMARY KEY ("id_thanh_toán");


--
-- Name: thÔng_bÁo thÔng_bÁo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."thÔng_bÁo"
    ADD CONSTRAINT "thÔng_bÁo_pkey" PRIMARY KEY ("id_thông_báo");


--
-- Name: tÀi_khoẢn tÀi_khoẢn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."tÀi_khoẢn"
    ADD CONSTRAINT "tÀi_khoẢn_pkey" PRIMARY KEY ("id_tài_khoản");


--
-- Name: ĐĂng_kÝ_dỊch_vỤ ĐĂng_kÝ_dỊch_vỤ_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ĐĂng_kÝ_dỊch_vỤ"
    ADD CONSTRAINT "ĐĂng_kÝ_dỊch_vỤ_pkey" PRIMARY KEY ("id_đăng_ký");


--
-- Name: chi_tiẾt_hoÁ_ĐƠn chi_tiẾt_hoÁ_ĐƠn_id_dịch_vụ_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."chi_tiẾt_hoÁ_ĐƠn"
    ADD CONSTRAINT "chi_tiẾt_hoÁ_ĐƠn_id_dịch_vụ_fkey" FOREIGN KEY ("id_dịch_vụ") REFERENCES public."dỊch_vỤ"("id_dịch_vụ");


--
-- Name: chi_tiẾt_hoÁ_ĐƠn chi_tiẾt_hoÁ_ĐƠn_id_hoá_đơn_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."chi_tiẾt_hoÁ_ĐƠn"
    ADD CONSTRAINT "chi_tiẾt_hoÁ_ĐƠn_id_hoá_đơn_fkey" FOREIGN KEY ("id_hoá_đơn") REFERENCES public."hoÁ_ĐƠn"("id_hoá_đơn");


--
-- Name: hoÁ_ĐƠn hoÁ_ĐƠn_id_hộ_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."hoÁ_ĐƠn"
    ADD CONSTRAINT "hoÁ_ĐƠn_id_hộ_fkey" FOREIGN KEY ("id_hộ") REFERENCES public."hỘ_cƯ_dÂn"("id_hộ");


--
-- Name: hỘ_cƯ_dÂn hỘ_cƯ_dÂn_id_tài_khoản_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."hỘ_cƯ_dÂn"
    ADD CONSTRAINT "hỘ_cƯ_dÂn_id_tài_khoản_fkey" FOREIGN KEY ("id_tài_khoản") REFERENCES public."tÀi_khoẢn"("id_tài_khoản");


--
-- Name: nhiỆm_vỤ nhiỆm_vỤ_id_người_giao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."nhiỆm_vỤ"
    ADD CONSTRAINT "nhiỆm_vỤ_id_người_giao_fkey" FOREIGN KEY ("id_người_giao") REFERENCES public."nhÂn_viÊn"("id_nhân_viên");


--
-- Name: nhiỆm_vỤ nhiỆm_vỤ_id_người_nhận_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."nhiỆm_vỤ"
    ADD CONSTRAINT "nhiỆm_vỤ_id_người_nhận_fkey" FOREIGN KEY ("id_người_nhận") REFERENCES public."nhÂn_viÊn"("id_nhân_viên");


--
-- Name: nhÂn_viÊn nhÂn_viÊn_id_bộ_phận_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."nhÂn_viÊn"
    ADD CONSTRAINT "nhÂn_viÊn_id_bộ_phận_fkey" FOREIGN KEY ("id_bộ_phận") REFERENCES public."bỘ_phẬn"("id_bộ_phận");


--
-- Name: nhÂn_viÊn nhÂn_viÊn_id_tài_khoản_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."nhÂn_viÊn"
    ADD CONSTRAINT "nhÂn_viÊn_id_tài_khoản_fkey" FOREIGN KEY ("id_tài_khoản") REFERENCES public."tÀi_khoẢn"("id_tài_khoản");


--
-- Name: sỰ_cỐ sỰ_cỐ_id_người_báo_cáo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."sỰ_cỐ"
    ADD CONSTRAINT "sỰ_cỐ_id_người_báo_cáo_fkey" FOREIGN KEY ("id_người_báo_cáo") REFERENCES public."nhÂn_viÊn"("id_nhân_viên");


--
-- Name: sỰ_cỐ sỰ_cỐ_id_người_trách_nhiệm_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."sỰ_cỐ"
    ADD CONSTRAINT "sỰ_cỐ_id_người_trách_nhiệm_fkey" FOREIGN KEY ("id_người_trách_nhiệm") REFERENCES public."nhÂn_viÊn"("id_nhân_viên");


--
-- Name: thanh_toÁn thanh_toÁn_id_hoá_đơn_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."thanh_toÁn"
    ADD CONSTRAINT "thanh_toÁn_id_hoá_đơn_fkey" FOREIGN KEY ("id_hoá_đơn") REFERENCES public."hoÁ_ĐƠn"("id_hoá_đơn");


--
-- Name: thanh_toÁn thanh_toÁn_id_người_xác_nhận_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."thanh_toÁn"
    ADD CONSTRAINT "thanh_toÁn_id_người_xác_nhận_fkey" FOREIGN KEY ("id_người_xác_nhận") REFERENCES public."nhÂn_viÊn"("id_nhân_viên");


--
-- Name: thÔng_bÁo thÔng_bÁo_id_hộ_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."thÔng_bÁo"
    ADD CONSTRAINT "thÔng_bÁo_id_hộ_fkey" FOREIGN KEY ("id_hộ") REFERENCES public."hỘ_cƯ_dÂn"("id_hộ");


--
-- Name: thÔng_bÁo thÔng_bÁo_id_thanh_toán_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."thÔng_bÁo"
    ADD CONSTRAINT "thÔng_bÁo_id_thanh_toán_fkey" FOREIGN KEY ("id_thanh_toán") REFERENCES public."thanh_toÁn"("id_thanh_toán");


--
-- Name: ĐĂng_kÝ_dỊch_vỤ ĐĂng_kÝ_dỊch_vỤ_id_dịch_vụ_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ĐĂng_kÝ_dỊch_vỤ"
    ADD CONSTRAINT "ĐĂng_kÝ_dỊch_vỤ_id_dịch_vụ_fkey" FOREIGN KEY ("id_dịch_vụ") REFERENCES public."dỊch_vỤ"("id_dịch_vụ");


--
-- Name: ĐĂng_kÝ_dỊch_vỤ ĐĂng_kÝ_dỊch_vỤ_id_hộ_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ĐĂng_kÝ_dỊch_vỤ"
    ADD CONSTRAINT "ĐĂng_kÝ_dỊch_vỤ_id_hộ_fkey" FOREIGN KEY ("id_hộ") REFERENCES public."hỘ_cƯ_dÂn"("id_hộ");


--
-- PostgreSQL database dump complete
--

